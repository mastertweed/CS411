import { Component, OnInit } from '@angular/core';
// import { MatFormField } from "@angular/material/form-field";

@Component({
  selector: 'app-preference-form',
  templateUrl: './preference-form.component.html',
  styleUrls: ['./preference-form.component.css']
})
export class PreferenceFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
