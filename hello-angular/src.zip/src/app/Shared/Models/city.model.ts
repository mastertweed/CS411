export interface City {
    city_id: number;
    city_name: string;
    median_age: number;
    population: number;
    median_income: number;
}