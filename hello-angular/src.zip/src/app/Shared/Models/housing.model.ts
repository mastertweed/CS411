import { NumberSymbol } from "@angular/common";

export interface Housing {
    county_id: string;
    median_price: number;
    bedrooms: number;
}