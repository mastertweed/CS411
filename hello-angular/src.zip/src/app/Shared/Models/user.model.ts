export interface User {
    user_id: number;
    user_name: string;
    income: number;
    city: string;
    age: number;
    password: string;
}