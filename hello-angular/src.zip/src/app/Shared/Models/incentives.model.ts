export interface Incentives {
    city_id: number;
    cash_payment: string;
    student_loans: string;
    paid_fellowship: string;
}