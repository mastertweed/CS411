export interface Location {
    state_id: number;
    income_tax: number;
    sales_tax: number;
    property_tax: number;
    regional_tax: number;
}