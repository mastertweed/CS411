export interface Climate {
    city_id: number;
    city_name: number;
    humidity: number;
    avg_rainfall: number;
    min_temp: number;
    max_temp: number;
}